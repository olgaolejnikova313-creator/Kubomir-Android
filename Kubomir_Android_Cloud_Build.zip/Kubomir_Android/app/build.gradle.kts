plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kubomir.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kubomir.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.4.5"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
